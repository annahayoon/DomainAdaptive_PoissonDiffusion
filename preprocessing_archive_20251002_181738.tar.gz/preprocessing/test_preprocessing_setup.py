#!/usr/bin/env python
"""
Test script to verify preprocessing setup and configurations.
Tests parallel processing, scale handling, and split consistency.
"""

import sys
import json
from pathlib import Path
import torch
import numpy as np

def test_parallel_imports():
    """Test if parallel utilities can be imported."""
    try:
        from preprocessing_utils_parallel import (
            parallel_extract_tiles_with_augmentation,
            memory_efficient_compute_global_scale,
            parallel_compute_noise_params,
        )
        print("✅ Parallel utilities imported successfully")
        return True
    except ImportError as e:
        print(f"⚠️ Parallel utilities not available: {e}")
        return False

def test_scale_compatibility(preprocessed_root: Path):
    """Test photography scale backward compatibility."""
    photo_posterior = preprocessed_root / "posterior" / "photography" / "train"
    
    if not photo_posterior.exists():
        print("⚠️ No photography posterior data found")
        return
    
    sample_files = list(photo_posterior.glob("*.pt"))[:5]
    
    for file_path in sample_files:
        data = torch.load(file_path, map_location='cpu')
        calibration = data.get('calibration', {})
        
        # Check backward compatibility
        if 'scale' in calibration:
            print(f"✅ Backward compatible 'scale' field present: {calibration['scale']:.1f}")
        else:
            print("❌ Missing 'scale' field for backward compatibility")
            
        # Check new dual scale fields
        if 'scale_noisy' in calibration and 'scale_clean' in calibration:
            print(f"✅ Dual scale fields present:")
            print(f"   - scale_noisy: {calibration['scale_noisy']:.1f}")
            print(f"   - scale_clean: {calibration['scale_clean']:.1f}")
            
            # Verify scale consistency
            if calibration['scale'] == calibration['scale_clean']:
                print("✅ Primary scale matches clean scale (consistent)")
            else:
                print("⚠️ Primary scale doesn't match clean scale")
        else:
            print("ℹ️ Dual scale fields not present (older format)")
        
        break  # Just check one file

def test_split_consistency_simple(preprocessed_root: Path):
    """Simple test for split consistency."""
    domains = ['photography', 'microscopy', 'astronomy']
    
    for domain in domains:
        print(f"\n--- Testing {domain} ---")
        
        prior_dir = preprocessed_root / "prior_clean" / domain
        posterior_dir = preprocessed_root / "posterior" / domain
        
        for split in ['train', 'val', 'test']:
            prior_split = prior_dir / split
            posterior_split = posterior_dir / split
            
            if prior_split.exists():
                prior_tiles = len(list(prior_split.glob("*.pt")))
                print(f"  {split}: {prior_tiles} prior tiles", end="")
            else:
                print(f"  {split}: No prior tiles", end="")
                
            if posterior_split.exists():
                posterior_scenes = len(list(posterior_split.glob("*.pt")))
                print(f", {posterior_scenes} posterior scenes")
            else:
                print(", No posterior scenes")

def test_tile_extraction_parallel():
    """Test parallel tile extraction."""
    try:
        from preprocessing_utils_parallel import parallel_extract_tiles_with_augmentation
        
        # Create dummy image
        dummy_image = np.random.randn(4, 256, 256).astype(np.float32)
        
        # Test parallel extraction
        tiles = parallel_extract_tiles_with_augmentation(
            dummy_image,
            num_tiles=10,
            tile_size=128,
            augment=True,
            n_workers=2
        )
        
        if len(tiles) > 0 and tiles[0].shape == (4, 128, 128):
            print(f"✅ Parallel tile extraction works: extracted {len(tiles)} tiles")
        else:
            print(f"❌ Parallel tile extraction issue: {len(tiles)} tiles, shape {tiles[0].shape if tiles else 'N/A'}")
            
    except Exception as e:
        print(f"❌ Parallel tile extraction failed: {e}")

def test_memory_efficient_scale():
    """Test memory-efficient scale computation."""
    try:
        from preprocessing_utils_parallel import memory_efficient_compute_global_scale
        
        # Create generator of dummy images
        def image_gen():
            for i in range(5):
                yield np.random.randn(4, 128, 128).astype(np.float32) * 1000
        
        scale = memory_efficient_compute_global_scale(
            image_gen(),
            num_images=5,
            percentile=99.9,
            batch_size=2
        )
        
        if scale > 0:
            print(f"✅ Memory-efficient scale computation works: scale={scale:.1f}")
        else:
            print(f"❌ Scale computation issue: scale={scale}")
            
    except Exception as e:
        print(f"❌ Memory-efficient scale computation failed: {e}")

def main():
    """Run all tests."""
    print("="*60)
    print("PREPROCESSING SETUP VERIFICATION")
    print("="*60)
    
    # Test 1: Parallel imports
    print("\n1. Testing parallel utilities...")
    has_parallel = test_parallel_imports()
    
    # Test 2: Parallel functionality
    if has_parallel:
        print("\n2. Testing parallel tile extraction...")
        test_tile_extraction_parallel()
        
        print("\n3. Testing memory-efficient scale computation...")
        test_memory_efficient_scale()
    else:
        print("\n⚠️ Skipping parallel functionality tests")
    
    # Test 3: Check preprocessed data if available
    preprocessed_root = Path("/path/to/preprocessed")  # Update this path
    if preprocessed_root.exists():
        print(f"\n4. Testing scale compatibility in {preprocessed_root}...")
        test_scale_compatibility(preprocessed_root)
        
        print(f"\n5. Testing split consistency...")
        test_split_consistency_simple(preprocessed_root)
    else:
        print(f"\n⚠️ Preprocessed data not found at {preprocessed_root}")
        print("   Update the path or run preprocessing first")
    
    print("\n" + "="*60)
    print("VERIFICATION COMPLETE")
    print("="*60)

if __name__ == "__main__":
    # Allow import from current directory
    sys.path.insert(0, str(Path(__file__).parent))
    main()
